 package javazap;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.net.UnknownHostException;
import java.io.PrintStream;

public class Saida {

	public static void main(String[] args) throws UnknownHostException, IOException {
		Socket client = new Socket("127.0.0.1", 10000);
		System.out.println("conectado");
		
		Scanner s = new Scanner(System.in);
		PrintStream out = new PrintStream(client.getOutputStream());
		
		while(s.hasNextLine()) {
			out.println(s.nextLine());
		}
		
		out.close();
		s.close();
		client.close();
	}

}
